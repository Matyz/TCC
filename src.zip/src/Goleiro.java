
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Goleiro extends Jogador {

    private boolean reposicionado = false;
    private boolean pertoDaFlag = false;    //flag que indica se o goleiro está posicionado no centro do gol
    private boolean moveTop = true;
    private boolean moveBottom = false;
    private boolean viradoPraFrente = false;
    private boolean _2movimentos = false;
    private boolean virando = false;

    private ObjectInfo bolaMomentoInicial;
    private ObjectInfo bolaMomentoFinal;

    private double distanciaFlagBaixo = 7.01;
    private double distanciaFlagCima = 7.01;
    private int tempoEspera = 0;
    private Memory m_memory;
    private Matematica matematica;

    public Goleiro(InetAddress host, int port, String team) throws SocketException {
        super(host, port, team);
    }

    @Override
    protected void init() {
        send("(init " + team + " (version 9)(goalie))");
    }

    @Override
    public void estrategiaDeJogo() {

        m_memory = brain.getM_memory();
        matematica = brain.getMatematica();

        ObjectInfo bola = m_memory.getObject("ball");
        ObjectInfo linhaFundo = m_memory.getObject("goal " + lado);
        ObjectInfo flagAreaC = m_memory.getObject("flag p " + lado + " c");

        ObjectInfo rival = m_memory.rivalMaisProximo(team);

        if (brain.getM_playMode().equals("free_kick_" + lado)) {
            if (!reposicionado) {
                posicionarNoGol();
            } else {
                cobrarTiroDeMeta();
            }
        } else {
            if (bola == null) {
                if (virando) {
                    virarFrente();
                } else {
                    posicionarNoGol();
                }
            } else {
                if (bola.m_distance < 1) {
                    goalie_catch(bola.m_direction);
                } else if (bola.m_distance < 13 && rival != null) {
                    if (matematica.distanciaEntre2Objetos(bola, rival) > bola.m_distance && (bola.m_distChange > -1.0)) {
                        pertoDaFlag = false;
                        if (Math.abs(bola.m_direction) < 10) {
                            dash(100);
                        } else {
                            turn(bola.m_direction);
                        }
                    } else {
                        cercarAnguloDeChute();
                    }
                } else if (bola.m_distance >= 13 && bola.m_distance <= 30 && bola.m_distChange < 0) {
                    cercarAnguloDeChute(); //posiciona-se pára a bola                   
                }
                reposicionado = false;
            }
        }
    }

    private void cercarAnguloDeChute() {
        int cont = 0;
        virarFrente();
        while (cont < 3) {
            ObjectInfo bola = m_memory.getObject("ball");
            if (cont == 0 && bola != null) {
                bolaMomentoInicial = bola;
                turn(bola.m_direction);
            } else if (cont == 2 && bola != null) {
                bolaMomentoFinal = bola;
                turn(bola.m_direction);
                double distancia = matematica.distanciaEntre2Objetos(bolaMomentoInicial, bolaMomentoFinal);
                double pX = matematica.getX(bolaMomentoInicial.m_distance, bolaMomentoInicial.m_direction);
                double pY = matematica.getY(bolaMomentoInicial.m_distance, bolaMomentoInicial.m_direction);
                double aresta, anguloA, anguloB;
                anguloA = matematica.calcularAngulos(bolaMomentoFinal.m_distance, bolaMomentoInicial.m_distance, distancia);

                if (bolaMomentoFinal.m_direction < 0) {
                    aresta = matematica.distanciaEntre2Pontos(pX, pY, distanciaFlagBaixo, 0);
                    BigDecimal bd = new BigDecimal(aresta).setScale(3, RoundingMode.HALF_EVEN);
                    aresta = bd.doubleValue();
                    anguloB = matematica.calcularAngulos(distanciaFlagBaixo, aresta, bolaMomentoInicial.m_distance);
                } else {
                    aresta = matematica.distanciaEntre2Pontos(pX, pY, distanciaFlagCima, 0);
                    BigDecimal bd = new BigDecimal(aresta).setScale(3, RoundingMode.HALF_EVEN);
                    aresta = bd.doubleValue();
                    anguloB = matematica.calcularAngulos(distanciaFlagCima, aresta, bolaMomentoInicial.m_distance);
                }

                if (anguloA <= anguloB) {
                    System.out.println("VAI PRO GOL");
                } else {
                    System.out.println("NÃO VAI PRO GOL");
                }

                viradoPraFrente = false;
                virando = false;
                tempoEspera = 0;
            }
            cont++;
            try {
                Thread.sleep(2 * SoccerParams.simulator_step);
            } catch (InterruptedException ex) {
                Logger.getLogger(Goleiro.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void virarFrente() {
        boolean virado = false;
        while (!virado) {
            ObjectInfo flagGolBaixo = m_memory.getObject("flag g " + lado + " t");
            try {
                if (flagGolBaixo != null && flagGolBaixo.m_direction != 0) {
                    turn(flagGolBaixo.m_direction);
                } else if (flagGolBaixo != null && flagGolBaixo.m_direction == 0) {
                    turn(-95);
                    distanciaFlagBaixo = flagGolBaixo.m_distance;
                    distanciaFlagCima = 14.02 - distanciaFlagBaixo;
                    virado = true;
                } else {
                    if (lado == 'r') {
                        turn(25);
                    } else {
                        turn(-25);
                    }
                }
                Thread.sleep(2 * SoccerParams.simulator_step);
            } catch (InterruptedException ex) {
                Logger.getLogger(Goleiro.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void posicionarNoGol() {
        boolean repos = false;
        while (!repos) {
            ObjectInfo linhaFundo = m_memory.getObject("goal " + lado);
            ObjectInfo flagAreaC = m_memory.getObject("flag p " + lado + " c");
            if (linhaFundo == null && !pertoDaFlag) {
                turn(45);
            } else if (linhaFundo != null && linhaFundo.m_direction != 0 && !pertoDaFlag) {
                turn(linhaFundo.m_direction);
            } else if (linhaFundo != null && linhaFundo.m_distance > 1.5) {
                dash(100);
            } else if (flagAreaC == null) {
                pertoDaFlag = true;
                turn(45);
            } else {
                turn(flagAreaC.m_direction);
                repos = true;
            }
            try {
                Thread.sleep(2 * SoccerParams.simulator_step);
            } catch (InterruptedException ex) {
                Logger.getLogger(Goleiro.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void cobrarTiroDeMeta() {
        boolean isMarcado;
        for (int i = 0; i < 2; i++) {
            if (i == 1) {
                move(-40, 15);
            }
            if (i == 2) {
                move(-40, -15);
            }
            ArrayList<ObjectInfo> companheiros = m_memory.companheirosNaVisao(team);
            ArrayList<ObjectInfo> rivais = m_memory.rivaisNaVisao(team);
            ArrayList<Double> distancias = new ArrayList<>();

            for (ObjectInfo companheiro : companheiros) {
                isMarcado = false;
                double distancia;
                double menorDistancia = 1000;

                for (ObjectInfo rival : rivais) {
                    distancia = matematica.distanciaEntre2Objetos(companheiro, rival);
                    if (distancia <= MARCACAO) {
                        if (distancia < menorDistancia) {
                            menorDistancia = distancia;
                        }
                        isMarcado = true;
                        break;
                    }
                }
                if (!isMarcado) {
                    kick(80, companheiro.m_direction);
                    return;
                } else {
                    distancias.add(menorDistancia);
                }

            }
            if (_2movimentos) {
                double maiorDistancia = 0;
                int index = -1;
              /*  for (int i = 0; i < distancias.size(); i++) {
                    if (maiorDistancia < distancias.get(i)) {
                        maiorDistancia = distancias.get(i);
                        index = i;
                    }
                }*/
                moveTop = true;
                moveBottom = false;
                _2movimentos = false;
                pertoDaFlag = false;
                if (index != -1) {
                    ObjectInfo companheiroMenosMarcado = companheiros.get(index);
                    kick(100, companheiroMenosMarcado.m_direction);
                } else {
                    kick(100, 0);
                }
            } else {
                moveBottom = true;
            }
        }
    }

    public static void main(String a[]) throws SocketException, IOException {
        String hostName = "";
        int port = 6000;
        String team = "Krislet3";

        try {
            for (int c = 0; c < a.length; c += 2) {
                if (a[c].compareTo("-host") == 0) {
                    hostName = a[c + 1];
                } else if (a[c].compareTo("-port") == 0) {
                    port = Integer.parseInt(a[c + 1]);
                } else if (a[c].compareTo("-team") == 0) {
                    team = a[c + 1];
                } else {
                    throw new Exception();
                }

            }
        } catch (Exception e) {
            System.err.println("");
            System.err.println("USAGE: krislet [-parameter value]");
            System.err.println("");
            System.err.println("    Parameters  value          default");
            System.err.println("   --------------------------------------");
            System.err.println("    host        host_name      localhost");
            System.err.println("    port        port_number    6000");
            System.err.println("    team        team_name      Kris");
            System.err.println("");
            System.err.println("    Example:");
            System.err.println("      krislet -host www.host.com -port 6000 -team Poland");
            System.err.println("    or");
            System.err.println("      krislet -host 193.117.005.223");
            return;
        }

        Jogador jogador = new Goleiro((InetAddress.getByName(hostName)), port, team);
        jogador.mainLoop();
    }

    @Override
    public void posicaoEmCampo() {
        move(-50.0, 0.0);
    }

    @Override
    public void pontapeInicial() {

    }

}
