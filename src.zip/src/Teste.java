/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Valderlei
 */
public class Teste {

    public static void main(String[] args) {

        Matematica m = new Matematica();
        double pX = m.getX(5, 0);
        double pY = m.getY(5, 0);
        
        double distancia = m.distanciaEntre2Pontos(7.01,0 , pX, pY);
        double angulo = m.calcularAngulos(distancia, 5, 7.01);
        
        System.out.println(m.radianoToGraus(angulo));
    }

}
