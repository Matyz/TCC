public class SoccerParams {
	final static int	simulator_step = 100;
}

